package com.seller.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.seller.entity.Product;
@Repository
public interface SellerRepository extends JpaRepository<Product, Integer> {

	Product save(Optional<Product> product);

}
