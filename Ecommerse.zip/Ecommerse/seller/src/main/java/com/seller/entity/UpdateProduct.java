package com.seller.entity;

import org.springframework.stereotype.Component;

@Component
public class UpdateProduct {
	
	private int stackNumber;
	private float price;
	public int getStackNumber() {
		return stackNumber;
	}
	public void setStackNumber(int stackNumber) {
		this.stackNumber = stackNumber;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	

}
