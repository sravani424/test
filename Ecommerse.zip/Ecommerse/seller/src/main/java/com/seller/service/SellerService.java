package com.seller.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seller.entity.Product;
import com.seller.entity.UpdateProduct;
import com.seller.repository.SellerRepository;

@Service
public class SellerService {

	@Autowired
	private SellerRepository repo;
	public Product saveProduct(Product product) {
		
		return repo.save(product);
	}
	public Optional<Product> updateProduct(Integer productId, UpdateProduct updateProduct) {
		Optional<Product> product = repo.findById(productId);
		product.get().setStockNumber(updateProduct.getStackNumber());
	    product.get().setPrice(updateProduct.getPrice());
	    repo.save(product);
		return product;
		
	}
	public List<Product> getProductDetails() {
		return repo.findAll();
	}

}
