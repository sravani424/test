package com.seller.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seller.entity.Product;
import com.seller.entity.UpdateProduct;
import com.seller.service.SellerService;

@RestController
@RequestMapping("/seller/product")
public class SellerController {

	@Autowired
	private SellerService sellerService;
	
	@PostMapping("/addProduct")
	public Product saveProduct(@RequestBody Product product){
		Product newProduct = null;
		if(product!=null) {
			newProduct =sellerService.saveProduct(product);
		}
		return newProduct;
	}
	
	@PutMapping("/updateProduct/{productId}")
	public Optional<Product> updateProduct(@PathVariable Integer productId,@RequestBody UpdateProduct updateProduct) {
		Optional<Product> updatedProduct = null;
		if(productId!=null && updateProduct!=null) {
			updatedProduct = sellerService.updateProduct(productId, updateProduct);
		}
		return updatedProduct;
	}
	
	@GetMapping("getProductDetails")
	public List<Product> getProductDetails(){
		return sellerService.getProductDetails();
	}
	
	
}
